@extends('wisatas.layout')
@section('content')
<form action="{{route('wisatas.update',$wisata -> id)}}" method="post">
    @csrf
    @method('PUT')
    <table class="table table-striped">
        <tr>
            <td>Nama</td>
            <td><input type="text" name="nama" id="" value="{{$wisata -> nama}}"></td>
        </tr>
        <tr>
            <td>Kota</td>
            <td><input type="text" name="kota" id=""value="{{$wisata -> kota}}"></td>
        </tr>
        <tr>
            <td>Harga Tiket</td>
            <td><input type="text" name="harga_tiket" id=""value="{{$wisata -> harga_tiket}}"></td>
        </tr>
        
    </table>
    <input type="submit" value="Simpan">
</form>
@endsection