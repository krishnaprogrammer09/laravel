@extends('wisatas.layout')
@section('content')
<h3>Name :{{$wisata -> nama}}</h3>
<h3>category :{{$wisata -> kota}}</h3>
<h3>employee :{{$wisata -> harga_tiket}}</h3>

@endsection