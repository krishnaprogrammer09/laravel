@extends('wisatas.layout')
@section('content')
<form action="{{route('wisatas.store')}}" method="post" enctype="multipart/form-data">
    @csrf
    <table class="table table-striped">
        <tr>
            <td>Nama</td>
            <td><input type="text" name="nama" id=""></td>
        </tr>
        <tr>
            <td>Kota</td>
            <td><input type="text" name="kota" id=""></td>
        </tr>
        <tr>
            <td>Harga Tiket</td>
            <td><input type="text" name="harga_tiket" id=""></td>
        </tr>
        <tr>
            <td>Image</td>
            <td><input type="file" name="image" id=""></td>
        </tr>
    </table>
    <input type="submit" value="Simpan">
</form>
@endsection