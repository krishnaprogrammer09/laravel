@extends('wisatas.layout')
@section('content')
<a href="{{route('wisatas.create')}}" class="btn btn-primary">Tambah </a>
<table class="table table-striped">
    <tr>
        <th>Id</th>
        <th>Image</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Aksi</th>
    </tr>
    @foreach($wisatas as $wisata)
    <tr>
        <td>{{$wisata -> id}}</td>
        <td><img src="{{Storage::url('public/images/').$wisata->image}}" alt="" style="width:150px;"></td>
        <td>{{$wisata -> nama}}</td>
        <td>{{$wisata -> kota}}</td>
        <td>{{$wisata -> harga_tiket}}</td>
        <td>
        <a href="{{route('wisatas.show',$wisata -> id)}}" class="btn btn-primary">Show </a>
        <a href="{{route('wisatas.edit',$wisata -> id)}}" class="btn btn-primary">Edit </a>
        <form onclick="return confirm('apakah anda yakin?')"action="{{route('wisatas.destroy',$wisata -> id)}}" method="post" style="display:inline;">
        @csrf
        @method('DELETE')
        <button class="btn btn-primary">Delete</button>
        </form>
        </td>
    </tr>
    @endforeach
</table>
{{$wisatas -> links()}}
@endsection
