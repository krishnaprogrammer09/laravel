<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('wisatas.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <table class="table table-striped">
        <tr>
            <td>Nama</td>
            <td><input type="text" name="nama" id=""></td>
        </tr>
        <tr>
            <td>Kota</td>
            <td><input type="text" name="kota" id=""></td>
        </tr>
        <tr>
            <td>Harga Tiket</td>
            <td><input type="text" name="harga_tiket" id=""></td>
        </tr>
        <tr>
            <td>Image</td>
            <td><input type="file" name="image" id=""></td>
        </tr>
    </table>
    <input type="submit" value="Simpan">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata/resources/views/wisatas/create.blade.php ENDPATH**/ ?>