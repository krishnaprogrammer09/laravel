<?php $__env->startSection('content'); ?>
<h3>Name :<?php echo e($wisata -> nama); ?></h3>
<h3>category :<?php echo e($wisata -> kota); ?></h3>
<h3>employee :<?php echo e($wisata -> harga_tiket); ?></h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata/resources/views/wisatas/show.blade.php ENDPATH**/ ?>